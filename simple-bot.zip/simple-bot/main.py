# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import random
import datetime
import telebot
from telebot import types

token = "5272965553:AAHSHNzj2UmIxYp_b17SADoyRllmGouRpl0"

bot = telebot.TeleBot(token)


@bot.message_handler(commands=['start'])
def start(message):
    keyboard = types.ReplyKeyboardMarkup()
    keyboard.row("Хочу", "/help", "/joke", "/date", "/draw", "/latin")
    bot.send_message(message.chat.id, 'Привет! Хочешь узнать свежую информацию о МТУСИ?', reply_markup=keyboard)


@bot.message_handler(commands=['help'])
def start_message(message):
    bot.send_message(message.chat.id, 'Я умею смешно шутить, подбрасывать монетку, переводить кирилицу в латницу, уточнять время\n'
                                      '/joke - шутка юмора\n/date - точная дата и время\n'
                                      '/draw - подбросить монетку\n/latin - перевод в латиницу')


@bot.message_handler(commands=['latin'])
def translit_latin(message):
    bot.send_message(message.chat.id, 'Введите тект, который нужно перевести в латиницу')
    bot.register_next_step_handler(message, func)

def func(message):
    text = message.text.lower()
    t = {'ё':'yo', 'а':'a', 'б':'b', 'в':'v', 'г':'g', 'д':'d', 'е':'e', 'ж':'zh', 'з':'z', 'и':'i', 'й':'y', 'к':'k', 'л':'l', 'м':'m',
         'н':'n', 'о':'o', 'п':'p', 'р':'r', 'с':'s', 'т':'t', 'у':'u', 'ф':'f', 'х':'h', 'ц':'c', 'ч':'ch', 'ш':'sh', 'щ':'shch', 'ъ':'',
         'ы':'y', 'ь':'', 'э':'e', 'ю':'yu', 'я':'ya'}
    for i in t:
        text = text.replace(i, t[i])
    bot.send_message(message.chat.id, text)



@bot.message_handler(commands=['draw'])
def draw(message):
    i = random.randint(0,1)
    if i == 0:
        bot.send_message(message.chat.id, 'Орел')
    if i == 1:
        bot.send_message(message.chat.id, 'Решка')


@bot.message_handler(commands=['date'])
def send_time_and_date(message):
    bot.send_message(message.chat.id, str(datetime.datetime.now()))


@bot.message_handler(commands=['joke'])
def send_joke(message):
    i = random.randint(0, 3)
    if i == 0:
        bot.send_message(message.chat.id, '-ты кто такой? \n-вор \n-а почему такой маленький? \n-карманный')
    if i == 1:
        bot.send_message(message.chat.id, 'У физрука было четыре сына: первый, второй, первый, второй')
    if i == 2:
        bot.send_message(message.chat.id, 'Почему на Северном полюсе нет реперов? Потому что невозможно зачитать под такой минус')
    if i == 3:
        bot.send_message(message.chat.id, 'Что говорит говорящая ворона, когда видит машину? Кар!')

@bot.message_handler(content_types=['text'])
def answer(message):
    if message.text.lower() == "хочу":
        bot.send_message(message.chat.id, "Тогда тебе сюда - https://mtuci.ru/")
    elif message.text.lower() == "ты кто?":
        bot.send_message(message.chat.id, "Я бот, который нужен для сдачи лабы...((")
    elif message.text.lower() == "любое сообщение":
        bot.send_message(message.chat.id, "Любой ответ")
    elif message.text.lower() == "три закона робототехники":
        bot.send_message(message.chat.id, "1)Робот не может причинить вред человеку или своим бездействием допустить, " 
                                          "чтобы человеку был причинён вред\n"
                                          "2)Робот должен повиноваться всем приказам, которые даёт человек, "
                                          "кроме тех случаев, когда эти приказы противоречат Первому Закону\n"
                                          "3)Робот должен заботиться о своей безопасности в той мере, "
                                          "в которой это не противоречит Первому или Второму Законам")
    else: bot.send_message(message.chat.id, "Я вас не понимаю ;(")

bot.infinity_polling()
